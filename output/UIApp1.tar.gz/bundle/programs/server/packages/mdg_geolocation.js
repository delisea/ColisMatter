(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mdg:geolocation'] = {};

})();
