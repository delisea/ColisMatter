var require = meteorInstall({"lib":{"main.js":function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// lib/main.js                                                             //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
/*                                                                         // 1
	_ID,                                                                      //
	Nom,                                                                      //
	Tag,                                                                      //
	Depart,                                                                   //
	Destination,                                                              //
	DateCreation,                                                             //
	Propriétaire:	_idUser,                                                    //
	Valide:			Boolean                                                         //
*/CoListe = new Mongo.Collection('colis');                                 //
Devices = new Mongo.Collection('devices'); /*                              // 14
                                           	_id,                           //
                                           	Date,                          //
                                           	Descriptif,                    //
                                           	Coordinates                    //
                                           */                              //
Itinerraires = new Mongo.Collection('itinerraires'); /*                    // 22
                                                     	_id,                 //
                                                     	Tag,                 //
                                                     	Descriptif,          //
                                                     	AbsentDepuis: _idIt,
                                                     	RetrouveA:    _idIt,
                                                     	Colis:		  _idColis   //
                                                     */                    //
Articles = new Mongo.Collection('articles');                               // 32
/////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["meteor/meteor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// server/main.js                                                          //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
var Meteor = void 0;                                                       // 1
module.import('meteor/meteor', {                                           // 1
      "Meteor": function (v) {                                             // 1
            Meteor = v;                                                    // 1
      }                                                                    // 1
}, 0);                                                                     // 1
//Meteor.startup(() => {                                                   // 3
// code to run on server at startup                                        // 4
//});                                                                      // 5
Meteor.startup(function () {                                               // 7
      return Meteor.methods({                                              // 9
            removeAllPosts: function () {                                  // 11
                  console.log("Serveur clean device");                     // 13
                  Devices.remove({});                                      // 14
            },                                                             // 16
            removeAllColis: function () {                                  // 17
                  console.log("Serveur clean colist");                     // 19
                  CoListe.remove({});                                      // 20
            }                                                              // 22
      });                                                                  // 9
});                                                                        // 26
/////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/main.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
